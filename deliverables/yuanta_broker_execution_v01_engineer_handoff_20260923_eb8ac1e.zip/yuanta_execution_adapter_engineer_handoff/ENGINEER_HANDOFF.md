# Yuanta SPARK execution adapter - engineer handoff

Date: 2026-09-23 (Asia/Taipei)
Source commit: `eb8ac1e9e7c0958c1baccbe28dca9fbc6c1b4516`

## What this package is

This is a corrected broker execution component for Yuanta SPARK domestic
securities. It contains a real `SendStockOrder` path, durable order state,
partial-fill handling, callback deduplication, cancellation/modification,
restart reconciliation and a fail-closed LIVE gate.

It is a library, not a complete unattended trading application. There is no
runner, scheduler, credential bundle or enabled production configuration in
this package.

## Mandatory integration boundary

Keep the following call chain. Do not call the broker from the signal engine:

```text
Signal Engine
  -> Risk Manager
  -> APPROVED strategy intent
  -> bridge_strategy_intent
  -> Order Manager
  -> YuantaSparkExecutionAdapter
```

`submit()` intentionally rejects raw mappings and arbitrary strategy objects.
Only the canonical broker `ExecutionIntent` produced after risk approval may
cross the adapter boundary.

## LIVE gate - do not bypass

A broker send is allowed only when all three values are present:

```text
EXECUTION_MODE=LIVE
ENABLE_LIVE_TRADING=YES
CLI flag --live
```

Create the immutable snapshot with:

```python
gate = LiveTradingGate.from_environment(cli_live=args.live)
```

The process must then complete `adapter.reconcile()` successfully. Do not add a
production bypass for reconciliation. Do not convert the three controls into a
single boolean, and do not make LIVE the default.

## Strategy conversion

Use `bridge_strategy_intent()` to map:

- `stock_id` to `symbol`
- `quantity_lots * 1000` to broker shares
- `suggested_limit_price` to the limit price
- `intent_type` to `ENTRY` or `EXIT`

Sell-first and buy-to-cover intents require an explicit, reviewed Yuanta
`StockOrderType`. The bridge deliberately refuses to guess CASH, SHORT_SELL,
borrow sell or DAY_TRADE_CONTROL from BUY/SELL alone.

Before enabling sell-first trading, verify the account's eligibility and the
`OrderType=9` behavior in Yuanta UAT with Yuanta's current documentation or
support. Do not use a production order as the first contract test.

## Position ownership and reconciliation

Broker inventory is keyed by `SYMBOL|TradeKind`:

- `0`: cash
- `3`: margin buy
- `4`: short sell
- `6`: borrow sell

Short and borrow quantities are represented as negative exposure. Categories
must not be netted against each other.

Existing manual inventory must be reviewed by the user and supplied explicitly
as `position_baseline`, for example:

```python
position_baseline={"2330|0": 1000, "2603|4": -1000}
```

Never adopt all current broker positions automatically as the baseline. An
unknown or mismatched position must halt new entries while preserving the
ability to cancel and flatten through the surrounding order manager.

## Required surrounding controls

This adapter does not replace the trading system's risk manager. Before any
production integration, the runner must enforce at least:

- max order value
- max position per stock
- max concurrent positions
- max trades per day
- realized plus unrealized daily loss limit
- no-new-position time
- force-flat time
- quote staleness and market-data disconnect handling
- account and trading-day preflight
- user-visible startup banner and notifications
- kill switch that blocks entries but retains cancel/flatten capability

## SDK and tests

The loader performs an offline reflection check before login for:

- `SendStockOrder(account, orders, language)`
- `GetRealReport(account, language)`
- `GetRealReportMerge(account, language)`
- `GetStoreSummary(account, language)`
- required `StockOrder` fields

Run mock tests:

```bash
cd stock-strategy
python3 -m unittest discover -s yuanta_broker_execution_v01/tests -v
```

Run the installed-SDK contract test without login or broker requests:

```bash
cd stock-strategy
YUANTA_VENDOR_DIR=/absolute/path/to/YuantaSparkAPI_osx-arm64_Python \
  /absolute/path/to/YuantaSparkAPI_osx-arm64_Python/.venv/bin/python \
  -m unittest yuanta_broker_execution_v01.tests.test_sdk_contract -v
```

Automated tests must use fake/UAT infrastructure and must never send a PROD
order. Production enablement requires a separate reviewed runner and an
operator-controlled deployment procedure.

## Secrets

Do not commit account numbers, passwords, certificate passwords, PFX files,
tokens or runtime SQLite databases. Load secrets from the existing Keychain or
another approved local secret store.
